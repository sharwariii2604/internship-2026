{
  "version": 1,
  "author": "Anonymous maker",
  "editor": "wokwi",
  "parts": [
    {
      "type": "wokwi-arduino-uno",
      "id": "uno",
      "top": -22.2,
      "left": -56.2,
      "rotate": 90,
      "attrs": {}
    },
    {
      "type": "wokwi-pushbutton",
      "id": "btn1",
      "top": 102.2,
      "left": -153.6,
      "attrs": { "color": "green", "xray": "1" }
    },
    { "type": "wokwi-lcd1602", "id": "lcd1", "top": -246.17, "left": 198.4, "attrs": {} },
    { "type": "wokwi-potentiometer", "id": "pot1", "top": 200.3, "left": 335.8, "attrs": {} }
  ],
  "connections": [
    [ "lcd1:RS", "uno:7", "yellow", [ "v0" ] ],
    [ "lcd1:E", "uno:8", "limegreen", [ "v0" ] ],
    [ "lcd1:D4", "uno:9", "magenta", [ "v0" ] ],
    [ "lcd1:D5", "uno:10", "cyan", [ "v0" ] ],
    [ "lcd1:D6", "uno:11", "magenta", [ "v0" ] ],
    [ "lcd1:D7", "uno:12", "yellow", [ "v0" ] ],
    [ "lcd1:A", "uno:5V", "purple", [ "v19.2", "h-451.3", "v134.4" ] ],
    [ "lcd1:K", "uno:GND.3", "magenta", [ "v38.4", "h-422.4", "v201.6" ] ],
    [ "lcd1:VDD", "uno:5V", "cyan", [ "v28.8", "h-307.1", "v192" ] ],
    [ "lcd1:VSS", "uno:GND.3", "yellow", [ "v48", "h-268.8", "v0" ] ],
    [ "lcd1:RW", "uno:GND.3", "green", [ "v9.6", "h-297.7", "v230.4" ] ],
    [ "lcd1:V0", "pot1:SIG", "green", [ "v412.8", "h124.5" ] ],
    [ "pot1:GND", "uno:5V", "black", [ "v19.2", "h-393.6", "v-182.4" ] ],
    [ "pot1:VCC", "uno:GND.3", "red", [ "v38.4", "h-432.8", "v-182.4" ] ],
    [ "btn1:1.r", "uno:2", "green", [ "v0", "h19.4", "v124.8", "h288", "v-57.6" ] ],
    [ "btn1:2.r", "uno:GND.2", "green", [ "h29", "v0.2" ] ]
  ],
  "dependencies": {}
}